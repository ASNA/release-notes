<h5 id="SinceVersion">Changes Since Version: 17.1.13.0</h5>

<span class="changeNoteHeading">Services</span>
<ul>
    <li>Case 21780. ASNA Coordinator fails when registry key contains invalid data.</li>
</ul>

<span class="changeNoteHeading">Clients - DataGate</span>
<ul>
    <li>Case 21751. Import CSV should remove Text Delimeter.</li>
    <li>Case 21778. DG Linear doesn't handle 'datetime' *Lowvalue for add/update.</li>
</ul>

<span class="changeNoteHeading">Registration Assistant</span>
<ul>
    <li>Case 21780. ASNA Coordinator fails when registry key contains invalid data.</li>
</ul>