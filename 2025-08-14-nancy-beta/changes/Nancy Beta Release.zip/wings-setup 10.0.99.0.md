<h5 id="SinceVersion">Changes Since Version: 10.0.98.0</h5>

<span class="changeNoteHeading">Services</span>
<ul>
    <li>Case 21780. ASNA Coordinator fails when registry key contains invalid string data.</li>
</ul>

<span class="changeNoteHeading">Registration Assistant</span>
<ul>
    <li>Case 21780. ASNA Coordinator fails when registry key contains invalid string data.</li>
</ul>