﻿<h5 id="SinceVersion">Changes Since Version: 16.0.104.0</h5>

<span class="changeNoteHeading"> Clients - DataGate</span>
<ul>
    <li>Case 21749. Throw dgException when using *DOMAIN with servers that do not support Negotiate authentication.</li>
</ul>

<span class="changeNoteHeading"> Clients - DataGate Explorer</span>
<ul>
    <li>Case 21763. SQL Logical files crash file definition designer.</li>
</ul>

<span class="changeNoteHeading"> Registration Assistant</span>
<ul>
    <li>Case 21764. "Invalid Response" error at start up.</li>
</ul>

<span class="changeNoteHeading"> Services</span>
<ul>
    <li>ASNA Coordinator - replaces existing ASNA services; resolves a vulnerability issue.</li>
    <li>Case 21759. Potential buffer overflow from usage of unsafe function.</li>
    <li>Case 21764. "Invalid Response" error at start up.</li>
</ul>
