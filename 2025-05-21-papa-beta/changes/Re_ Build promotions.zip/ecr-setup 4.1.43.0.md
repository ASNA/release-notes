﻿<h5 id="SinceVersion">Changes Since Version: 4.1.42.0</h5>

<span class="changeNoteHeading"> QSys - DataGate Client</span>
<ul>
    <li>Fix SQL login password bug.</li>
</ul>

<span class="changeNoteHeading"> RnD - Encore Compiler</span>
<ul>
    <li>Extended ByteType with the same funcionality of IntegerType to support byte enumerations: type equality now considers whether the byte type is an enum; casting is forced if the type is enum.</li>
</ul>

<span class="changeNoteHeading"> RnD - Encore File Usage Generator</span>
<ul>
    <li>Use the original record name (with @, $, etc) in the format IDs dictionary. (#1)</li>
</ul>
