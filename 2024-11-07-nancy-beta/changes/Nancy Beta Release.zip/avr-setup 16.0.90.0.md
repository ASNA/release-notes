﻿<h5 id="SinceVersion">Changes Since Version: 16.0.89.0</h5>

<span class="changeNoteHeading"> Clients - DataGate Controls</span>
<ul>
    <li>Case 21738. Import Database Names Command does not overwrite existing names.</li>
</ul>

<span class="changeNoteHeading"> Clients - DataGate Explorer</span>
<ul>
    <li>Case 21741. "Connections" Node Serialization Errors Are Not Displayed.</li>
</ul>

<span class="changeNoteHeading"> Clients - DataGate Monitor</span>
<ul>
    <li>Case 21737. Import Database Names Command Fails.</li>
</ul>
