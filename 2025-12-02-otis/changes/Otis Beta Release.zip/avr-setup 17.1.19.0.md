<h5 id="SinceVersion">Changes Since Version: 17.1.18.0</h5>

<span class="changeNoteHeading">DataGate Server</span>
<ul>
    <li>Case 21782. Removing all system library list items returns DSS error.</li>
</ul>

<span class="changeNoteHeading">Visual RPG IDE Project</span>
<ul>
    <li>Case 21784. Error &quot;The path is not relative&quot; when loading windows forms project.</li>
</ul>