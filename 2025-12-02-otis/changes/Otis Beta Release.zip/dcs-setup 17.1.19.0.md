<h5 id="SinceVersion">Changes Since Version: 17.1.18.0</h5>

<span class="changeNoteHeading">DataGate Server</span>
<ul>
    <li>Case 21782. Removing all system library list items returns DSS error.</li>
</ul>