<h5 id="SinceVersion">Changes Since Version: 11.1.17.0</h5>

<span class="changeNoteHeading">QSys - DataGate.Client</span>
<ul>
    <li>Various bug fixes.</li>
</ul>
