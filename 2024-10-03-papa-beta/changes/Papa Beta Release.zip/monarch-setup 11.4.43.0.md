﻿<h5 id="SinceVersion">Changes Since Version: 11.4.42.0</h5>

<span class="changeNoteHeading"> Monarch Cocoon</span>
<ul>
    <li>Case 21049. Do not generate VirtualRowCol for output-only fields</li>
    <li>Case 21743. Fields in a Row of a Record with same Col position are not migrated.</li>
</ul>