<h5 id="SinceVersion">Changes Since Version: 11.4.61.0</h5>

<span class="changeNoteHeading">Monarch Cocoon</span>
<ul>
    <li>Case 21119 Migration of ENSR for *PSSR is using wrong namespace.</li>
    <li>Case 21235 Pull *PSSR Implementation out of Procedure.</li>
    <li>Case 21789 Interpret DSPF38 Syntax for REFFLD.</li>
    <li>Case 7813 Need better implementation for CHKOBJ.</li>
    <li>Case 21339 Add support for ALTPAGEDWN and ALTPAGEUP.</li>
</ul>