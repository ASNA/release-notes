<h5 id="SinceVersion">Changes Since Version: 4.1.50.0</h5>

<span class="changeNoteHeading">RnD - Encore Compiler</span>
<ul>
    <li>Fixed validation of overloaded INFSR.</li>
</ul>