﻿<h5 id="SinceVersion">Changes Since Version: 17.0.33.0</h5>

<span class="changeNoteHeading"> Clients - DataGate Controls</span>
<ul>
    <li>Case 21738. Import database names command does not overwrite existing names.</li>
</ul>

<span class="changeNoteHeading"> Clients - DataGate Explorer</span>
<ul>
    <li>Case 21741. "Connections" node serialization errors are not displayed.</li>
</ul>

<span class="changeNoteHeading"> Clients - DataGate Monitor</span>
<ul>
    <li>Case 21737. Import database names command fails.</li>
</ul>

<span class="changeNoteHeading"> Clients - Runtime</span>
<ul>
    <li>Case 21733. Output operations with a FROMDS that has a packed number throws exception at runtime.</li>
</ul>
