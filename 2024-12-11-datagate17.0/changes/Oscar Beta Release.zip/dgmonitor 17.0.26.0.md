﻿<h5 id="SinceVersion">Changes Since Version: 17.0.23.0</h5>

<span class="changeNoteHeading"> Clients - DataGate Controls</span>
<ul>
    <li>Case 21738. Import database names command does not overwrite existing names.</li>
</ul>

<span class="changeNoteHeading"> Clients - DataGate Monitor</span>
<ul>
    <li>Case 21737. Import database names command fails.</li>
</ul>
