﻿<h5 id="SinceVersion">Changes Since Version: 10.0.88.0</h5>

<span class="changeNoteHeading"> Clients - DataGate Explorer</span>
<ul>
    <li>Case 21606. Copy and Copy OLE Print Fielddef Source to Project crashes Visual Studio.</li>
</ul>
