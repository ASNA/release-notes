﻿<h5 id="SinceVersion">Changes Since Version: 10.0.58.0</h5>

<span class="changeNoteHeading">Synon Escape</span>
<ul>
    <li>Various bug fixes.</li>
</ul>