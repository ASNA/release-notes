﻿<h5 id="SinceVersion">Changes Since Version: 10.0.87.0</h5>

<span class="changeNoteHeading">Monarch Cocoon</span>
<ul>
    <li>Various bug fixes.</li>
</ul>