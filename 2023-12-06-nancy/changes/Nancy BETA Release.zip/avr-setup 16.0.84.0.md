﻿<h5 id="SinceVersion">Changes Since Version: 16.0.83.0</h5>

<span class="changeNoteHeading"> Clients - DataGate Explorer</span>
<ul>
    <li>Case 21606. Copy and Copy OLE Print Fielddef Source to Project crashes Visual Studio.</li>
</ul>
