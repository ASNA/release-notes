﻿<h5 id="SinceVersion">Changes Since Version: 16.0.82.0</h5>

<span class="changeNoteHeading">Nomad</span>
<ul>
    <li>Various bug fixes.</li>
</ul>