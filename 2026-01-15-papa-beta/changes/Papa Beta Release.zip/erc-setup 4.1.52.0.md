<h5 id="SinceVersion">Changes Since Version: 4.1.51.0</h5>


<span class="changeNoteHeading">QSys - Expo</span>
<ul>
    <li>Check for Attn &amp; EndRequest key before attempting to set Resulting Indicators.</li>
</ul>

<span class="changeNoteHeading">QSys - Runtime</span>
<ul>
    <li>Make RetrieveUserProfile Public and use Ind type for INLR on AttentionProgram calling.</li>
</ul>

<span class="changeNoteHeading">RnD - Encore Compiler</span>
<ul>
    <li>Fixed wrong syntax for .net 6.</li>
</ul>
