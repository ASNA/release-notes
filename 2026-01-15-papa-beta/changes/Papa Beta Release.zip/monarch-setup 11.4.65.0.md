<h5 id="SinceVersion">Changes Since Version: 11.4.64.0</h5>

<span class="changeNoteHeading">RnD - Cocoon Dotnet Templates</span>
<ul>
    <li>Use the &quot;next&quot; version of the JavaScript Library.</li>
</ul>