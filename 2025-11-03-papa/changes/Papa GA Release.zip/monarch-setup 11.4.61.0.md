<h5 id="SinceVersion">Changes Since Version: 11.4.58.0</h5>

<span class="changeNoteHeading">Clients - DataGate</span>
<ul>
    <li>Case 21751. Import CSV should remove Text Delimeter.</li>
    <li>Case 21778. DG Linear doesn't handle 'datetime' *Lowvalue for add/update.</li>
</ul>

<span class="changeNoteHeading">Monarch Cocoon</span>
<ul>
    <li>Case 422. Add support for ALTHELP DDS Keyword.</li>
    <li>Case 21339. Add support for ALTPAGEDWN and ALTPAGEUP.</li>
    <li>Case 21725. Add support for FONT Name/Size DDS keyword.</li>
    <li>Case 21786. Add support for CRTLIB and DLTLIB.</li>
    <li>Case 21787. Add support for RTVJOBA&#39;s keyword CYMDDATE.</li>
    <li>Case 21788. Convert Record Formats with CLRL(*NO) to Window Records.</li>
    <li>Case 21789.  Interpret DSPF38 Syntax for REFFLD.</li>
    <li>Case 21790. Add support for HELP keyword without indicator when DDS has no help specs/keywords.</li>
</ul>
