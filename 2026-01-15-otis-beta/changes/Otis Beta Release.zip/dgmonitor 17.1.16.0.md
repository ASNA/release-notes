<h5 id="SinceVersion">Changes Since Version: 17.1.15.0</h5>

<span class="changeNoteHeading">DataGate Monitor</span>
<ul>
    <li>Various bug fixes.</li>
</ul>