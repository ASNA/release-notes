<h5 id="SinceVersion">Changes Since Version: 17.1.19.0</h5>

<span class="changeNoteHeading">Visual RPG for .NET</span>
<ul>
    <li>IDE freezes when hitting a breakpoint and hovering a variable (which should show a tool tip with its value).</li>
    <li>Not being able to display fields with special characters (#$@) in their names.</li>
    <li>Debugger was showing internal compiler generated fields, they are now correctly hidden.</li>
</ul>