<h5 id="SinceVersion">Changes Since Version: 17.1.19.0</h5>

<span class="changeNoteHeading">DataGate for SQL Server</span>
<ul>
    <li>Various bug fixes.</li>
</ul>
