﻿<h5 id="SinceVersion">Changes Since Version: 11.4.43.0</h5>

<span class="changeNoteHeading"> RnD - Cocoon Dotnet Templates </span>
<ul>
    <li>Added OutputType to class-library projects.</li>
    <li>Target .NET 8.</li>
</ul>
