﻿<h5 id="SinceVersion">Changes Since Version: 11.4.56.0</h5>

<span class="changeNoteHeading"> RnD - Cocoon Dotnet Templates</span>
<ul>
    <li>Implement DynamicList</li>
    <li>Implement option on OVRDBF for WaitFile</li>
</ul>

<span class="changeNoteHeading"> RnD - Cocoon Dotnet Templates</span>
<ul>
    <li>Updated AbEnd.cshtml in Website.</li>
    <li>Remove quotes from template. Cocoon adds the quotes accordingly.</li>
</ul>
