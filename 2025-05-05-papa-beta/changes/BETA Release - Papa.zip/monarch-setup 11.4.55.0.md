﻿<h5 id="SinceVersion">Changes Since Version: 11.4.50.0</h5>

<span class="changeNoteHeading">ASNA Services</span>
<ul>
    <li>ASNA Coordinator - replaces existing ASNA services; resolves a vulnerability issue.</li>
</ul>

<span class="changeNoteHeading"> RnD - Cocoon Dotnet Templates</span>
<ul>
    <li>Updated Expo Client Library to 5.x.</li>
    <li>Removed quotes in the CallD program name (to allow for possible /Error warning need of parameters). (#39)</li>
    <li>Remove the MessageFiles folder item group from the template for the website project file.</li>
</ul>
